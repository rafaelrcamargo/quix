<p align="center"><img width="200px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/VTEX_Logo.svg/1024px-VTEX_Logo.svg.png" alt="icon"></p>

# VTEX IO - Store starter!!

Ester é o projeto minimo para criar uma store de e-commerce usando VTEX IO.

_Usado no artigo sobre apps custom da CommerceXperts!_
